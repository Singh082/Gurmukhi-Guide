// Akali Phula Singh Ji
import SwiftUI // Import SwiftUI

struct AkaliPhula: View { // Define the AkaliPhula view
    var body: some View { // Define the body of the view
        ZStack { // Use ZStack to layer background and content
            Image("Wallpaper") // Background wallpaper image
                .resizable() // Make image resizable
                .scaledToFill() // Scale image to fill the view
                .ignoresSafeArea() // Extend image to ignore safe area
            
            VStack { // Vertical stack for content
                ScrollView { // Scrollable content
                    
                    Image("Akali Phula Singh") // Display Akali Phula Singh Ji image
                        .resizable() // Make image resizable
                        .scaledToFit() // Scale image to fit frame
                        .frame(width: 300, height: 300) // Set frame size
                        .offset(y: 0) // Offset image downward
                    Text("Image By: SikhiWiki")
                        .foregroundColor(Color.white)
                        .offset(y: 10)

                    
                    Text("Akali Phula Singh Ji") // Display name
                        .font(.headline) // Set font style
                        .bold() // Bold the text
                        .offset(y: 10) // Offset text downward
                        .foregroundColor(.white) // Set text color to white
                    
                    Divider() // Horizontal line divider
                        .offset(y:100) // Offset divider downward
                    
                    Text("Akali Baba Phula Singh was born on 14th January 1761 in Sarinh village in the present-day Sangrur district in Punjab. Born in a devout Sikh family, his father, Baba Ishar Singh of Misal Shaheedan, died soon after the occurrence of the Wadda Ghalughara in 1762. From his early days, Phula Singh was influenced by Sikh teachings. He was a part of the Jatha of Akali Baba Naina Singh ji, which was a part of the Misal Shaheedan. This Jatha was one of the first five Khalsa divisions. This Jatha was responsible for spreading Gurbaani, Shastar vidya, Naam Abhyaas, and maintaining Gurudwaras and Takhats. Trained in Gurbaani and Shastar vidya at Sri Amritsar Sahib, Phula Singh later rose to prominence as a leader of a group of fearless warriors known as Nihangs. Nihangs are saint warriors created by Guru Gobind Singh ji. They are known for their fearlessness and unwavering commitment to the Khalsa. They have sacrificed their personal lives in the service of the Khalsa. Phula Singh was never married in his life. He played an important role in bringing peace to the warring groups in Amritsar and later joined Maharaja Ranjit Singh's army, becoming Jathedar of the Akal Takht in 1807. He even took disciplinary action against the Maharaja for marrying outside his faith, indicating the level of respect he was held in due to his position and character. Phula Singh was against the Europeanization of the Khalsa army; instead, he believed in traditional Sikh military power. He helped Maharaja Ranjit Singh in battles in Punjab against Kasur, Multan, Peshawar, etc., and was instrumental in the modernization of the army under the guidance of French General Ventura. He was a true leader and brave man who was devoted to Sikhism and left behind a legacy that would last forever.") // Detailed biography text
                        .padding() // Add padding
                        .frame(maxWidth: .infinity, alignment: .leading) // Expand width and align leading
                        .multilineTextAlignment(.leading) // Align multiline text to leading
                        .frame(width: 400, height: .infinity) // Set explicit frame width
                        .offset(y: 10) // Offset text downward
                        .foregroundColor(.white) // Set text color to white
                }
            }
        }
    }
}
