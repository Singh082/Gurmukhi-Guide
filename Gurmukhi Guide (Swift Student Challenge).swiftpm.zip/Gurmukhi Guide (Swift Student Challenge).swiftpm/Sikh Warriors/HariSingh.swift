// Hari Singh Nalwa Ji
import SwiftUI // Import SwiftUI 

struct HariSingh: View { // Define the HariSingh view
    var body: some View { // Body of the view
        ZStack { // Stack background and content layers
            Image("Wallpaper") // Background image
                .resizable() // Make it resizable
                .scaledToFill() // Fill the view
                .ignoresSafeArea() // Extend into safe area
            
            VStack { // Vertical stack for main content
                ScrollView { // Scrollable content
                    
                    Image("Hari Singh Nalwa") // Image of Hari Singh Nalwa Ji
                        .resizable() // Make image resizable
                        .scaledToFit() // Fit image within frame
                        .frame(width: 300, height: 300) // Set size of image
                        .offset(y: 10) // Offset downward
                    Text("Image By: SikhNet")
                        .foregroundColor(Color.white)
                        .offset(y: 10)

                    
                    Text("Hari Singh Nalwa") // Name text
                        .font(.headline) // Set headline font
                        .bold() // Bold text
                        .offset(y: 10) // Offset downward
                        .foregroundColor(.white) // White color
                    
                    Divider() // Horizontal line
                        .offset(y: 10) // Offset downward
                    
                    Text("Hari Singh was born in Gujranwala in the Punjab region of the Indian subcontinent to a Sikh family from the village of Majitha in the district of Amritsar. His father, Gurdial Singh Uppal, and grandfather, Hardas Singh Uppal, were both brave warriors in the Sukerchakia Misl army. The grandfather was martyred in the battle against Ahmad Shah Durrani in 1762. Hari Singh’s father passed away when he was just seven years old, but he was raised by his mother, Dharam Kaur. She made sure that Hari Singh was well trained in horse-riding, sword-fighting, shooting, and speaking Punjabi and Persian. Hari Singh moved to Gujranwala at the age of thirteen in 1804 and joined the Sikh army that year. He excelled in drill work, which caught the eye of Maharaja Ranjit Singh, who appointed him as an attendant in his personal service in no time. In 1805, Hari Singh was conferred with the title of “Sardar” and was given command of 800 horsemen due to his incredible act of killing a tiger single-handedly while horse-riding in 1804, after which he came to be known as “Nalwa” or “Baaghmaar.” He fought in important battles under Maharaja Ranjit Singh in Kasur, Multan, Sialkot, Sahival, Khushab, Attock, and other areas, and later served as governor in Kashmir, restoring peace and establishing forts, gurudwaras, and gardens. He also developed the famous fort and town of Harikishangarh and Haripur to secure the northwest frontier for trade. As Commander-in-Chief in the sensitive northwest frontier, Hari Singh developed the famous Khyber Pass, defeating the Afghans in the Battle of Jamrud, preventing further invasions from Afghanistan. In his final battle on 30th April 1837, despite receiving many sabre cuts and cannon shots, Hari Singh remained in charge until he received a fatal gunshot wound, showing his bravery and commitment. Hari Singh Nalwa is remembered as the “Champion of the Khalsa.” He was a brilliant administrator, a brave warrior, and a great leader for the Khalsa Empire in the Punjab and northwest frontier areas.") // Detailed biography text
                        .padding() // Add padding around text
                        .frame(maxWidth: .infinity, alignment: .leading) // Expand width and align leading
                        .multilineTextAlignment(.leading) // Align multiline text
                        .frame(width: 400, height: .infinity) // Explicit frame width
                        .offset(y: 10) // Offset downward
                        .foregroundColor(.white) // White text color
                }
            }
        }
    }
}
