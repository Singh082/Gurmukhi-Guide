// Warriors Main Screen
import SwiftUI // Importing SwiftUI framework for UI components

struct Warriors: View { // Main view for displaying Sikh warriors
    var body: some View {
        ZStack { // Layered stack for background and content
            Image("Wallpaper") // Background image
                .resizable() // Makes the image resizable
                .scaledToFill() // Fills the screen without maintaining aspect ratio
                .ignoresSafeArea() // Extends image to edges, ignoring safe area
            
            VStack { // Vertical stack for content
                ScrollView { // Allows scrolling when content exceeds screen
                    Text("LEARN ABOUT THE SIKH WARRIORS") // Main heading text
                        .font(.headline) // Sets font style
                        .offset(x: 05, y: 30) // Moves text slightly down and right
                        .bold() // Makes text bold
                        .foregroundColor(.white) // Sets text color to white
                    
                    Text("Please Press The Picture To Learn Their Name") // Instruction text
                        .padding() // Adds padding around text
                        .bold() // Makes text bold
                        .offset(x: 05, y: 20) // Moves text slightly down and right
                        .foregroundColor(.white) // Sets text color to white
                    
                    // Navigation link to Akali Phula Singh detail screen
                    NavigationLink(destination: AkaliPhula()) {
                        Image("Akali Phula Singh") // Warrior image
                            .resizable() // Makes image resizable
                            .scaledToFit() // Maintains aspect ratio
                            .frame(width: 250, height: 250) // Sets image size
                            .padding() // Adds padding around image
                    }
                    
                    // Navigation link to Baba Deep Singh detail screen
                    NavigationLink(destination: BabaDeep()) {
                        Image("Baba Deep Singh") // Warrior image
                            .resizable()
                            .scaledToFit()
                            .frame(width: 250, height: 250)
                            .padding()
                    }
                    
                    // Navigation link to Baba Banda Singh Bahadur detail screen
                    NavigationLink(destination: BabaBanda()) {
                        Image("Baba Banda Singh Bahadur") // Warrior image
                            .resizable()
                            .scaledToFit()
                            .frame(width: 250, height: 250)
                            .padding()
                    }
                    
                    // Navigation link to Hari Singh Nalwa detail screen
                    NavigationLink(destination: HariSingh()) {
                        Image("Hari Singh Nalwa") // Warrior image
                            .resizable()
                            .scaledToFit()
                            .frame(width: 250, height: 250)
                            .padding()
                    }
                    
                    // Navigation link to Maharaja Ranjit Singh detail screen
                    NavigationLink(destination: RanjitSingh()) {
                        Image("Maharaja Ranjit Singh") // Warrior image
                            .resizable()
                            .scaledToFit()
                            .frame(width: 250, height: 250)
                            .padding()
                    }
                    
                    // Navigation link to Mai Bhago detail screen
                    NavigationLink(destination: MaiBhago()) {
                        Image("Mai Bhago") // Warrior image
                            .resizable()
                            .scaledToFit()
                            .frame(width: 250, height: 250)
                            .padding()
                    }
                    .padding(.bottom, 175) // Adds extra padding at the bottom for scrolling
                }
            }
        }
    }
}
