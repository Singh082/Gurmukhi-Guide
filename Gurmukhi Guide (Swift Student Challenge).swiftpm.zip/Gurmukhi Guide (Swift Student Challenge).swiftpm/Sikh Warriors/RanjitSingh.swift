// Maharaja Ranjit Singh Ji
import SwiftUI // Import SwiftUI

struct RanjitSingh: View { // Define the RanjitSingh view
    var body: some View { // Main body of the view
        ZStack { // ZStack to layer background and content
            Image("Wallpaper") // Background wallpaper image
                .resizable() // Allow image resizing
                .scaledToFill() // Scale image to fill screen
                .ignoresSafeArea() // Extend image into safe areas
            
            VStack { // Vertical stack for main content
                ScrollView { // Enable vertical scrolling
                    
                    Image("Maharaja Ranjit Singh") // Image of Maharaja Ranjit Singh
                        .resizable() // Make image resizable
                        .scaledToFit() // Fit image proportionally
                        .frame(width: 300, height: 300) // Set image size
                        .offset(y: 10) // Push image downward
                    Text("Image By: Organiser")
                        .foregroundColor(Color.white)
                        .offset(y: 10)

                    
                    Text("Maharaja Ranjit Singh") // Title text
                        .font(.headline) // Headline font style
                        .bold() // Bold text
                        .offset(y: 10) // Push text downward
                        .foregroundColor(.white) // White text color
                    
                    Divider() // Divider line
                        .offset(y: 10) // Push divider downward
                    
                    Text("Maharaja Ranjit Singh was originally named Budh Singh. Born to Sardar Mahan Singh of Gujranwala and Raj Kaur, also known as Mai Malwain of Jind, he was named Ranjit following his father’s victory over the Chattah tribe. His father had lost an eye to smallpox, but he excelled in martial arts, sports, and horse riding. When he was only ten years old, he witnessed his first battle as his father besieged Sodhran fort. Ranjit Singh succeeded his father as leader of Sukerchakia Misl in 1792 following his death. However, he left his mother and Diwan Lakhpat to manage affairs as he focused on hunting and training. Ranjit survived a murder attempt at age thirteen. He married Mehtab Kaur of Kanhaya Misl at age fifteen and then Raj Kaur, also known as Datar Kaur, in 1798. Ranjit took over affairs of the state at age eighteen. Punjab was politically divided at this time, with twelve Sikh confederacies, Afghan lands, and challenges from the Rajputs, Gurkhas, Marathas, and British. The most immediate threat was from the Afghans, who had long claimed northern India. Shah Zaman’s invasions of 1795-97 had weakened Afghan rule, and Ranjit was able to seize Lahore on 7 July 1799, liberating it from the Bhangi leaders. He was proclaimed Maharaja on 12 April 1801, becoming the preeminent ruler in northern India. In the decades that followed, he was able to extend his empire, incorporating Amritsar, Cis-Sutlej states, Kashmir (1819), Multan (1818), Peshawar (1823), and Leh in Ladakh (1836), securing the Punjab frontier against Afghan raids. The Treaty of Amritsar in 1809 regularized his relations with the British and established his sovereignty over northern India north of the Sutlej. Ranjit Singh was a supporter of literature, arts, and inter-religious understanding, tolerating the Sikh, Hindu, and Islamic scriptures. Despite suffering from frequent attacks of paralysis, he continued to be actively engaged in governance until his death on 27 June 1839. During his reign, Punjab was a strong, rich, and united kingdom, and he was viewed by Europeans as a shrewd and able ruler.") // Biography text
                        .padding() // Add padding around text
                        .frame(maxWidth: .infinity, alignment: .leading) // Full width with left alignment
                        .multilineTextAlignment(.leading) // Align multi-line text to the left
                        .frame(width: 400, height: .infinity) // Fixed width frame
                        .offset(y: 10) // Push text downward
                        .foregroundColor(.white) // White text color
                }
            }
        }
    }
}

#Preview {
    RanjitSingh()
}
