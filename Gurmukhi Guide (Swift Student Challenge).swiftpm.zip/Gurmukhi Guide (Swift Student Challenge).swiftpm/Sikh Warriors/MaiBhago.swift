// Mai Bhago Ji
import SwiftUI // Import SwiftUI framework

struct MaiBhago: View { // Define the MaiBhago view
    var body: some View { // Body of the view
        ZStack { // Stack for background and content
            Image("Wallpaper") // Background wallpaper image
                .resizable() // Make the image resizable
                .scaledToFill() // Fill the view
                .ignoresSafeArea() // Extend into safe area
            
            VStack { // Vertical stack for main content
                ScrollView { // Scrollable content
                    
                    Image("Mai Bhago") // Image of Mai Bhago Ji
                        .resizable() // Make image resizable
                        .scaledToFit() // Fit the image
                        .frame(width: 300, height: 300) // Set image size
                        .offset(y: 10) // Offset downward
                    Text("Image By: Discover Sikhism")
                        .foregroundColor(Color.white)
                        .offset(y: 10)

                    
                    Text("Mai Bhago") // Name text
                        .font(.headline) // Headline font
                        .bold() // Bold text
                        .offset(y: 10) // Offset downward
                        .foregroundColor(.white) // White color
                    
                    Divider() // Horizontal line
                        .offset(y: 10) // Offset downward
                    
                    Text("Mai Bhago, or Mata Bhag Kaur, was in 1705 one of the most renowned Sikh saint-warriors. Born in Jhabal Kalan in Majha region of Punjab to Bhai Mallo Shah and the granddaughter of Bhai Piro Shah, Mai Bhago was brought up as a devoted Sikh and married Nidhan Singh Warraich of Patti. She was the only sister of her four brothers. At the time of the Battle of Anandpur Sahib, Mai Bhago came to learn of Sikhs from her area who had deserted Guru Gobind Singh Ji in difficult circumstances. In order to clear their names and seek forgiveness from the Guru, Mai Bhago convinced forty of these Sikhs, who came to be known as the Chali Mukta, to accompany her in finding the Guru while the Mughal army pursued him relentlessly. The final battle occurred near Khidrana dhab. Despite their decision to relinquish their Khalsa identity, Mai Bhago and her companions decided to fight the vastly outnumbered Mughal army of about 10,000 soldiers. Showing extraordinary courage and expertise, she led the charge herself, armed with a kirpan and wearing Khalsa regalia and keski. The Sikhs caused significant damage to the Mughal army, causing them to retreat by nightfall. Guru Gobind Singh Ji watched from a hilltop and even joined the fight with accurate archery before arriving at the scene. The forty Sikh soldiers, with the exception of Mahan Singh Brar who was mortally wounded, lost their lives as martyrs. Mai Bhago’s bravery made her the first woman in the history of Punjab to fight on a battlefield. Her bravery, courage, and devotion earned her immense respect and reverence. The Chali Mukta are remembered as Shaheeds—martyrs who lost their lives in the name of their religion and Khalsa.") // Detailed biography text
                        .padding() // Padding around text
                        .frame(maxWidth: .infinity, alignment: .leading) // Max width and leading alignment
                        .multilineTextAlignment(.leading) // Align multiline text
                        .frame(width: 400, height: .infinity) // Explicit frame
                        .offset(y: 10) // Offset downward
                        .foregroundColor(.white) // White text color
                }
            }
        }
    }
}
