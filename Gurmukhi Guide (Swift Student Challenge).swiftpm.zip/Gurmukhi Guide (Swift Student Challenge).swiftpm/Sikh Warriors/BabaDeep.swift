// Baba Deep Singh Ji
import SwiftUI // Import SwiftUI 

struct BabaDeep: View { // Define the BabaDeep view
    var body: some View { // Body of the view
        ZStack { // Layer background and content
            Image("Wallpaper") // Background wallpaper image
                .resizable() // Make image resizable
                .scaledToFill() // Scale image to fill the view
                .ignoresSafeArea() // Extend image into safe area
            
            VStack { // Vertical stack for content
                ScrollView { // Scrollable content
                    
                    Image("Baba Deep Singh") // Display Baba Deep Singh Ji image
                        .resizable() // Make image resizable
                        .scaledToFit() // Scale image to fit frame
                        .frame(width: 300, height: 300) // Set frame size
                        .offset(y: 10) // Offset image downward
                    Text("Image By: Singh Arts")
                        .foregroundColor(Color.white)
                        .offset(y: 10)

                    
                    Text("Baba Deep Singh") // Display name
                        .font(.headline) // Set font style
                        .bold() // Bold the text
                        .offset(y: 10) // Offset text downward
                        .foregroundColor(.white) // Set text color to white
                    
                    Divider() // Horizontal line divider
                        .offset(y: 10) // Offset divider downward
                    
                    Text("One of the greatest martyrs of Sikhism is Baba Deep Singh Shaheed. Born on 26th January 1682 in Pahuwind, a village near Amritsar, he was the only son of Bhai Bhagta Ji and Mai Jeoni Ji. He was named Deepa, meaning 'light.' At the young age of twelve, he encountered Guru Gobind Singh Ji at Anandpur Sahib. He then began his service to the Sikh community by studying the Sri Guru Granth Sahib with Bhai Mani Singh Ji and other prominent scholars. In addition, he also learned how to fight, hunt, and ride horses. At the age of eighteen, he took Amrit and pledged himself as a soldier of Waheguru. Baba Deep Singh Ji was made the first head of the renowned Damdami Taksal, a theological school founded by Guru Gobind Singh Ji. He assisted in the dissemination of the Guru Granth Sahib throughout India and abroad. After this, he returned to Punjab and married. However, his love for the Khalsa and Panth remained his top priority. He fought alongside Banda Singh Bahadur in the wars of Sirhind and other significant battles, helping defeat the oppressive Mughal Empire and bring justice to the family of Guru Gobind Singh Ji. Continuing to be the leader of Shahid Misl, Baba Deep Singh remained committed to upholding Sikh values, rescuing captives, and waging a struggle for freedom in Punjab. Significantly, during Ahmed Shah Abdali’s fourth invasion in 1755-56, he led his army to rescue hundreds of women and children from forced captivity. Baba Deep Singh has become famous for his bravery, erudition, and commitment to upholding truth and justice. Even in his final battle at Amritsar at the ripe age of 75, he remained true to the ideal of a saint-soldier. His base of operations at Talvandi Sabo and Burj Baba Deep Singh Shaheed near Damdama Sahib are symbols of his legacy, which was totally dedicated to the Panth, truth, and helping those who were oppressed.") // Detailed biography text
                        .padding() // Add padding around text
                        .frame(maxWidth: .infinity, alignment: .leading) // Expand width and align leading
                        .multilineTextAlignment(.leading) // Align multiline text to leading
                        .frame(width: 400, height: .infinity) // Explicit frame width
                        .offset(y: 10) // Offset text downward
                        .foregroundColor(.white) // Set text color to white
                }
            }
        }
    }
}
