// Baba Banda Singh Bahadur Ji
import SwiftUI // Import SwiftUI

struct BabaBanda: View { // Define the BabaBanda view
    var body: some View { // Body of the view
        ZStack { // Layer background and content
            Image("Wallpaper") // Background wallpaper image
                .resizable() // Make image resizable
                .scaledToFill() // Scale image to fill the view
                .ignoresSafeArea() // Extend image into safe area
            
            VStack { // Vertical stack for content
                ScrollView { // Scrollable content
                    
                    Image("Baba Banda Singh Bahadur") // Display Baba Banda Singh Ji image
                        .resizable() // Make image resizable
                        .scaledToFit() // Scale image to fit frame
                        .frame(width: 300, height: 300) // Set frame size
                        .offset(y: 10) // Offset image downward
                    Text("Image By: Dasvandh Network")
                        .foregroundColor(Color.white)
                        .offset(y: 10)
                    
                    
                    Text("Baba Banda Singh Bahadur") // Display name
                        .font(.headline) // Set font style
                        .bold() // Bold the text
                        .offset(y: 10) // Offset text downward
                        .foregroundColor(.white) // Set text color to white
                    
                    Divider() // Horizontal line divider
                        .offset(y: 75) // Offset divider downward
                    
                    Text("Baba Banda Singh Bahadur (16 October 1670 – 9 June 1716), born Lachhman Dev and also known by the name Madho Dass Bairagi, was born in Rajouri, Jammu, in a Minhas Rajput family. Since his early days, he was full of life and proficiency in hunting, horse riding, and wrestling. The turning point in his life came when he shot a doe. Seeing the mother and unborn baby die due to his act, he renounced the world and became a wandering ascetic under the guidance of Bairagi Sadhu Janaki Das, who renamed him Madho Das. Madho Das wandered across Northern India and finally reached Nanded on the banks of the Godavari River. In September 1708, Guru Gobind Singh passed by Nanded while fleeing from Bahadur Shah. The first meeting with Guru Gobind Singh was remarkable when Madho Das attempted to resist the authority of the Guru using his occult powers. However, he failed in all his attempts. After recognizing Guru Gobind Singh, he bowed before him and was directed to abandon his ascetic life and devote himself to the cause of defending righteousness and justice as a true warrior. Following the Guru’s advice, Banda Singh Bahadur went to Punjab to lead Sikh resistance against the Mughal Empire. The journey was quite long, covering over 1,600 kilometers from Nanded to Hissar. The journey took nearly a year as he moved slowly to evade the Mughal army. The attack on Guru Gobind Singh, which led to his death shortly before Banda Singh Bahadur’s arrival, only made Banda Bahadur even more determined to fight for justice and revenge. Baba Banda Singh Bahadur’s leadership sparked an incredible rebellion against Mughal oppression. Banda Singh Bahadur’s military actions created a platform for the formation of the Dal Khalsa, Sikh Misls, and eventually Maharaja Ranjit Singh’s Sikh Empire in Punjab in 1799. Banda Singh Bahadur is considered one of the greatest Sikh warriors and martyrs.") // Detailed biography text
                        .padding() // Add padding
                        .frame(maxWidth: .infinity, alignment: .leading) // Expand width and align leading
                        .multilineTextAlignment(.leading) // Align multiline text to leading
                        .frame(width: 400, height: .infinity) // Explicit frame width
                        .offset(y: 10) // Offset text downward
                        .foregroundColor(.white) // Set text color to white
                }
            }
        }
    }
}
