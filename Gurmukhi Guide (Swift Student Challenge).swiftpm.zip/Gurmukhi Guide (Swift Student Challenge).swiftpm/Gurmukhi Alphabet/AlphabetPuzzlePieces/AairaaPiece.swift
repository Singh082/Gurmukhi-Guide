// Aairaa Piece
import SwiftUI

//Main view for tracing the letter Aairaa
struct AairaaPiece: View {
    //Stores all the points the user draws while tracing
    @State private var points: [CGPoint] = []
    var body: some View {
        //Stack for the Background and Content
        ZStack {
            //Background Wallpaper
            Image("Wallpaper")
                .resizable()//Allows Image Resizing
                .scaledToFill()//Fills The Entire Screen
                .ignoresSafeArea()//Extends Image to The Screen Edges
            
            //Vertical Stack for the Title and Button
            VStack {
                //Text that needs to be traced
                Text("AAIRAA")
                    .offset(y: 20)//Moves Text Slightly Down
                    .font(.title)//Sets the Font Title
                    .bold()// Makes The Text Bold
                    .foregroundColor(.white)//Sets Font To White
                    .offset(y: -20)//Moves Text Upward
                
                //VStack For The Navigation Wor
                VStack {
                    //Navigation Link To THe Babbaa tracing screen
                    NavigationLink(destination: BabaPiece()) {
                        //Button Text
                        Text("Let's Trace Babbaa ->")
                            .padding() // Adds Inner Spacing
                            .frame(maxWidth: 300) // Sets the max width
                            .background(Color.orange) // Sets Background Color
                            .foregroundColor(.white) // Sets Text Color
                            .cornerRadius(10) // Rounds Button Corners
                            .padding(.top, 450) // Pushes The Button Down
                    }

                }
            }
            //ZStack for tracing letter
            ZStack {
                // Background letter to trace
                Text("ਅ")
                    .font(.system(size: 400)) // Sets the large font size
                    .foregroundColor(.white.opacity(0.3)) // Makes the Letter fade a bit
                    .offset(y: -50) //Letter Moves Upwards
                
                //Path for user drawing
                Path { path in
                    if let first = points.first {
                        path.move(to: first)
                        //Draws Line through all the points
                        for point in points.dropFirst() {
                            path.addLine(to: point)
                        }
                    }
                }
                //Gives the drawing line an orange
                .stroke(Color.orange, lineWidth: 8)
                
            }
            // Adds Drawing gesture for tracing
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { value in
                        points.append(value.location)
                    }
                    .onEnded { _ in
                    }
            )
        }
    }
        }

