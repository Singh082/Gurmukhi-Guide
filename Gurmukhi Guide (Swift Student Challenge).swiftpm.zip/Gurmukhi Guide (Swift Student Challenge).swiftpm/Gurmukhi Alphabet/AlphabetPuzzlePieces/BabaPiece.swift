// Babbaa Piece
import SwiftUI
import UIKit

//Main View
struct BabaPiece: View {
    //Stores the traced points
    @State private var points: [CGPoint] = []
    //View Layout
    var body: some View {
        ZStack {
            //Background Image
            Image("Wallpaper")
                .resizable()//Allows the image to resize
                .scaledToFill() // Fills the entire screen
                .ignoresSafeArea() // Extends the image beyond the safe areas
            
            //Vertical Stack for title and navigation
            VStack {
                //Title Text
                Text("BABBAA")
                    .offset(y: -20) //Moves text slightly upward
                    .font(.title) // Sets Title font
                    .bold() // Makes the text bold
                    .foregroundColor(.white) //Sets the text color to white
                
                //Stack for navigaton
                VStack {
                    //Navigating link to the next tracing screen
                    NavigationLink(destination: DaddaPiece()) {
                        //Button Text
                        Text("Let's Trace Daddaa ->")
                            .padding()//Adds Inner Spacing
                            .frame(maxWidth: 300) // Sets Max Width
                            .background(Color.orange) // Orange Background
                            .foregroundColor(.white) // White Text Color
                            .cornerRadius(10) // Rounds The Corners
                            .padding(.top, 450) // Pushes Button Downward
                    }
                }
            }
            // Stack for tracing background letter
            ZStack {
                // Background letter to trace
                Text("ਬ")
                    .font(.system(size: 400))//Sets the Font Size
                    .foregroundColor(.white.opacity(0.3)) // Semi - transparent Background
                    .offset(y: -50)// Moves Letter Upward
                
                //Draws the tracing path
                Path { path in
                    // Ensures there is at least one point
                    if let first = points.first {
                        path.move(to: first)
                        //Draws Lines Between All Points
                        for point in points.dropFirst() {
                            path.addLine(to: point)
                        }
                    }
                }
                //Styles the Path to Orange
                .stroke(Color.orange, lineWidth: 8)
                
            }
            //Gesture for tracking finger movement
            .gesture(
                DragGesture(minimumDistance: 0) //Detects the small movements
                    .onChanged { value in
                        points.append(value.location) // Adds the new trace point
                    }
                    .onEnded { _ in
                    }
            )
        }
    }
}
