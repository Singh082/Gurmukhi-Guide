// Zazzaa Screen
import SwiftUI
import UIKit
// Main view
struct ZazzaPiece: View {
    // Stores trace points
    @State private var points: [CGPoint] = []
    // View body
    var body: some View {
        // Layered layout
        ZStack {
            // Background image
            Image("Wallpaper")
                .resizable() // Resize image
                .scaledToFill() // Fill screen
                .ignoresSafeArea() // Ignore safe area
            // Title container
            VStack {
                // Title text
                Text("ZAZZAA")
                    .offset(y: -300) // Move up
                    .font(.title) // Title size
                    .bold() // Bold text
                    .foregroundColor(.white) // White color
            }
            // Tracing area
            ZStack {
                // Main Letter
                Text("ਜ਼")
                    .font(.system(size: 400)) // Large size
                    .foregroundColor(.white.opacity(0.3)) // Faded color
                    .offset(y: -100) // Move up
                
                Path { path in // Draw path
                    if let first = points.first { // Check first point
                        path.move(to: first) // Start path
                        for point in points.dropFirst() { // Loop points
                            path.addLine(to: point) // Draw line
                        }
                    }
                }
                .stroke(Color.orange, lineWidth: 8) // Path style
            }
            .gesture( // Track finger
                DragGesture(minimumDistance: 0)
                    .onChanged { value in
                        points.append(value.location) // Add point
                    }
                    .onEnded { _ in
                        // End tracing
                    }
            )
        }
    }
}
