// Daddaa Piece

import SwiftUI
import UIKit

//Main View
struct DaddaPiece: View {
    //Stores the tracing point
    @State private var points: [CGPoint] = []
    //View Body
    var body: some View {
        //Layered the layout
        ZStack {
            //Background Image
            Image("Wallpaper")
                .resizable() // Resize image
                .scaledToFill()// Fill screen
                .ignoresSafeArea() // Ignore safe area
            
            // Vertical layout
            VStack {
                // Title text
                Text("DADDAA")
                    .offset(y: 25)// Move up
                    .font(.title)// Title size
                    .bold()// Bold text
                    .foregroundColor(.white)// White Font color
                
                //Button Container
                VStack {
                    // Go to next screen
                    NavigationLink(destination: LallaPiece()) {
                        // Button text
                        Text("Let's Trace Lallaa ->")
                            .padding() // Inner spacing
                            .frame(maxWidth: 300) // Width limit
                            .background(Color.orange) // Button color
                            .foregroundColor(.white) // Text color
                            .cornerRadius(10) // Rounded corners
                            .padding(.top, 40) // Move down               }
                    }
                }
                // Tracing area
                ZStack {
                    // Background letter to trace
                    Text("ਦ")
                        .font(.system(size: 450)) // Large size
                        .foregroundColor(.white.opacity(0.3)) //Fades The Text
                        .offset(x: 0, y: 0) // Move up
                    
                    // Drawing path
                    Path { path in
                        if let first = points.first { // Check first point
                            path.move(to: first)// Start path
                            for point in points.dropFirst() {// Loop points
                                path.addLine(to: point)// Draw line
                            }
                        }
                    }
                    // Path style
                    .stroke(Color.orange, lineWidth: 8)
                    
                }
                // Track finger
                .gesture(
                    DragGesture(minimumDistance: 0)
                        .onChanged { value in
                            points.append(value.location) // Add point
                        }
                        .onEnded { _ in
                            // End tracing
                        }
                )
            }
        }
    }
    
}

#Preview {
    DaddaPiece()
}
