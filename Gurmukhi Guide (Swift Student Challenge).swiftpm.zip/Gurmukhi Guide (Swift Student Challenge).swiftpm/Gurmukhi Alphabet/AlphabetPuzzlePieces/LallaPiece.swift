// Lallaa Screen
import SwiftUI
import UIKit

//Main View
struct LallaPiece: View {
    //Stores The Trace Points
    @State private var points: [CGPoint] = []
    
    // View body
    var body: some View {
        // Layered layout
        ZStack {
            Image("Wallpaper") // Background image
                .resizable() // Resize image
                .scaledToFill() // Fill screen
                .ignoresSafeArea() // Ignore safe area
            
            // Vertical layout
            VStack {
                //Title Text
                Text("LALLAA")
                    .offset(y: -60) // Move up
                    .font(.title) // Title size
                    .bold() // Bold text
                    .foregroundColor(.white) // White color
                // Button container
                VStack {
                    // Button To Go To Next Screen
                    NavigationLink(destination: NannaPiece()) {
                        // Button text
                        Text("Let's Trace Nannaa ->")
                            .padding() // Inner spacing
                            .frame(maxWidth: 300) // Width limit
                            .background(Color.orange) // Button color
                            .foregroundColor(.white) // Text color
                            .cornerRadius(10) // Rounded corners
                            .padding(.top, 350) // Move down
                    }
                }
            }
            // Tracing area
            ZStack {
                //Letter
                Text("ਲ")
                    .font(.system(size: 450)) // Large size
                    .foregroundColor(.white.opacity(0.3)) // Faded color
                    .offset(y: -100) // Move up
                
                Path { path in // Draw path
                    if let first = points.first { // Check first point
                        path.move(to: first) // Start path
                        for point in points.dropFirst() { // Loop points
                            path.addLine(to: point) // Draw line
                        }
                    }
                }
                .stroke(Color.orange, lineWidth: 8) // Path style
            }
            .gesture( // Track finger
                DragGesture(minimumDistance: 0)
                    .onChanged { value in
                        points.append(value.location) // Add point
                    }
                    .onEnded { _ in
                        // End tracing
                    }
            )
        }
    }
}
