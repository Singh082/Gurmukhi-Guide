import SwiftUI
import UIKit

//Main view for the alphabet tracing puzzle
struct AlphabetPuzzle: View {
    //Stores the Points that are traced by the users
    @State private var points: [CGPoint] = []
    
    // Defines the UI layout
    var body: some View {
        // Layers background and content
        ZStack {
            // Background wallpaper image
            Image("Wallpaper")
                .resizable() // Allows the image to resize
                .scaledToFill() // Fills the entire screen
                .ignoresSafeArea() // Extends image to screen edges
                .allowsHitTesting(false) // Prevents interaction with background
            
            //Vertical Layout for the Content
            VStack {
                //Title text for thr Letter Oorhaaa
                Text("OORHAA")
                    .font(.title) // Sets title font size
                    .bold() // Makes text bold
                    .foregroundColor(.white) // Sets text color
                    .padding(.top, 40) // Adds top spacing
                
                //Pushes Content Apart
                Spacer()
                
                //Area where tracing happens
                GeometryReader { geo in
                    //Layer Background Letter and The Drawing
                    ZStack {
                        // Background letter
                        Text("ੳ")
                            .font(.system(size: 400)) // Large letter size
                            .foregroundColor(.white.opacity(0.3)) // Semi-transparent
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                        
                        // Path drawn by the user's finger
                        Path { path in
                            // Checks if there is at least one point
                            if let first = points.first {
                                path.move(to: first) // Starts path
                                // Draws lines between points
                                for point in points.dropFirst() {
                                    path.addLine(to: point)
                                }
                            }
                        }
                        .stroke(Color.orange, lineWidth: 8) //Styles the Path
                    }
                    .contentShape(Rectangle()) // Makes the Full Area Tappable
                    .gesture(
                        //Detects Dragging for Tracing
                        DragGesture(minimumDistance: 0)
                            .onChanged { value in
                                // Converts touch location to local coordinates
                                let localPoint = value.location
                                // Adds point to the traced path
                                points.append(localPoint)
                            }
                            .onEnded { _ in
                                //Runs when tracing ends
                            }
                    )
                }
                //Sets Tracing Area Height
                .frame(height: 400)
                
                //Adds Spacing
                Spacer()
                
                // Button to navigate to the next tracing screen
                NavigationLink(destination: AairaaPiece()) {
                    Text("Let's Trace Aairaa →")
                        .padding() // Adds inner spacing
                        .frame(maxWidth: 300)// Limits button width
                        .background(Color.orange) // Button background color
                        .foregroundColor(.white) // Button text color
                        .cornerRadius(20)// Rounds button corners
                        .padding(.bottom, 40) // Adds bottom spacing
                }
            }
            .padding()// Adds padding around content
        }
    }
}
