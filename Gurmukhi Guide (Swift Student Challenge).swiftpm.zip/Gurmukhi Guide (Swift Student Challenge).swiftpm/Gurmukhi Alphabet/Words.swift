//Imports Swift
import SwiftUI

//This defines the Gurmukhi Alphabet Screen
struct Words: View {
    var body: some View {
        //Stacks Layer Views On Top Of Each Other
        ZStack {
            //Background Image
            Image("Wallpaper")
                .resizable()//Allows The Image To Resize
                .scaledToFill()//Makes The Image Fill The Entire Screen
                .ignoresSafeArea()//Extends Image To The Edge of the Screen
            
            //Arranges The Content Vertically
            VStack {
                //Welcome Text To The Screen
                Text("Welcome To The Gurmukhi Alphabet Screen")
                    .padding()//Adds Spacing Around The Text
                    .foregroundColor(.white)//Makes Text White
                    .offset(y: -10)//Moves Text Slightly Up
                    .bold()//Makes Text Bold
                
                //Alphabet Image Display
                Image("Words")
                    .resizable()//Allows Resize
                    .scaledToFit()//Keeps Image Proportions
                    .frame(width: 500, height: 500)//Sets Image Size
                    .offset(x: 0)
                
                //Navigation Button to Alphabet Puzzle Screen
                NavigationLink(destination: WordsQuiz()) {
                    Text("Want To Do A Quiz To Understand The Words ->")
                        .padding()//Spacing Inside the Button
                        .frame(maxWidth: 430)//Sets Max Button Width
                        .background(Color.orange)//Button Background Color
                        .foregroundColor(.white)//Button Text Colour
                        .cornerRadius(10)//Rounds Button Corners
                }
            }
            
        }
        
    }
}

