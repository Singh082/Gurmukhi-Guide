import SwiftUI

//Main Quiz View
struct AlphabetQuiz: View {
    //Tracks The Current Question
    @State private var currentQuestion = 0
    //Stores The Selected Anser (a, b, c, d)
    //The term "nil" represents that There is no value here right now
    @State private var selectedAnswer: String? = nil
    //Keeps Track of User Score
    @State private var score = 0
    
    //Array Of Quiz Questions, Options and Correct Answers
    let questions: [(question: String, options: [String], answer: String)] = [
        //Question 1
        ("What Letter Is This: ੳ", ["a) Airhaa", "b) Ghaggaa", "c) Oorhaa", "d) Sassaa"], "c"),
        
        //Question 2
        ("What Letter Is This: ਬ", ["a) Airhaa", "b) Sassaa", "c) Babbaa", "d) Lallaa"], "c"),
        
        //Question 3
        ("What Letter Is This: ਵ", ["a) Vavvaa", "b) Ghaggaa", "c) Babbaa", "d) Oorhaa"], "a"),
        
        //Question 4
        ("What Letter Is This: ਤ", ["a) Tattaa", "b) Ghaggaa", "c) Sassaa", "d) Babbaa"], "a"),
        
        //Question 5
        ("What Letter Is This: ਫ", ["a) Phaphphaa", "b) Mammaa", "c) Dhaddaa", "d) Jhajjaa"], "a"),
        
        //Question 6
        ("What Letter Is This: ਮ", ["a) Tainkaa", "b) Mammaa", "c) Sassaa", "d) Jhajjaa"], "b")
    ]
    //Start of UI
    var body: some View {
        //Stacks Everything on Top Each Other
            ZStack {
                //Background Image
                Image("Wallpaper")
                    .resizable()//Makes It Resizable
                    .scaledToFill()//Scaled to Fill The Screen
                    .ignoresSafeArea()//Ignores The Safe Area
        
        //Verticallly Stacks Everything Below
        VStack(spacing: 20) {
            //Check IF Quiz is Done
            if currentQuestion < questions.count {
                //Shows the Question
                Text(questions[currentQuestion].question)
                    .font(.title)//Title Size
                    .multilineTextAlignment(.center)//Center Text
                    .foregroundColor(.white)// White Text
                
                //Loop Options
                ForEach(questions[currentQuestion].options, id: \.self) { option in
                    //If Button is Tapped
                    Button(action: {
                        //Get First Letter
                        let choice = String(option.prefix(1)) // get "a", "b", "c", "d"
                        //Saves Choices
                        selectedAnswer = choice
                        
                        //Check if Correct
                        if choice == questions[currentQuestion].answer {
                            score += 1 //Increases Score by 1
                        }
                        //Small Delay
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                            currentQuestion += 1 //Moves To Next Question
                        }
                    }) {
                        //Option Text
                        Text(option)
                            .padding()//Inner Spacing
                            .frame(maxWidth: 350)//Sets The Width
                            .background(Color.orange)//Orange Background
                            .cornerRadius(10)//Rounded Corers
                            .foregroundColor(.white)//White Text
                    }
                }
                //If Answer Chosen
                if let selected = selectedAnswer {
                    //Shows The Result
                    Text(selected == questions[currentQuestion].answer ? "✅ Correct!" : "❌ Wrong!")
                        .foregroundColor(selected == questions[currentQuestion].answer ? .green : .red)//Font is Green Or Red Based On Answer Result
                        .bold()
                }
            } else {
                //Message That Display's Quiz Is Finished
                Text("Quiz Finished!")
                    .font(.title)//Title Size
                    .foregroundColor(.white)//White Text
                    .bold()//Bold
                    .padding()//Spacing
                
                //Shows The Score Of The Quiz
                Text("Your score Is: \(score)/\(questions.count)")
                    .font(.title2)//Title Font
                    .padding()//Spacing
                    .foregroundColor(.white)//White Text
            }
        }
        .padding()
    }
    }
}
