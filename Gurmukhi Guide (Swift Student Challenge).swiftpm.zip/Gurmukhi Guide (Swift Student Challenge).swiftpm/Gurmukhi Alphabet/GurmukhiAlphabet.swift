//Imports Swift
import SwiftUI

//This defines the Gurmukhi Alphabet Screen
struct GurmukhiAlphabet: View {
    var body: some View {
        //Stacks Layer Views On Top Of Each Other
        ZStack {
            //Background Image
            Image("Wallpaper")
                .resizable() // Resize image
                .scaledToFill() // Fill screen
                .ignoresSafeArea() // Ignore safe area
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            
        //Arranges The Content Vertically
        VStack {
            //Welcome Text To The Screen
            Text("Welcome To The Gurmukhi Alphabet Screen")
                .padding()//Adds Spacing Around The Text
                .foregroundColor(.white)//Makes Text White
                .offset(y: -20)//Moves Text Slightly Up
                .bold()//Makes Text Bold
            
            //Alphabet Image Display
            Image("Alphabet1")
                .resizable()//Allows Resize
                .scaledToFit()//Keeps Image Proportions
                .frame(width: 1500, height: 500)//Sets Image Size
            
            //Navigation Button to Alphabet Puzzle Screen
            NavigationLink(destination: AlphabetPuzzle()) {
                Text("Let's Trace some of the Gurmukhi Alphabet ->")
                    .padding()//Spacing Inside the Button
                    .frame(maxWidth: 390)//Sets Max Button Width
                    .background(Color.orange)//Button Background Color
                    .foregroundColor(.white)//Button Text Colour
                    .cornerRadius(10)//Rounds Button Corners
            }
            //Navigation Button to Alphabet Quiz Screen
            NavigationLink(destination: AlphabetQuiz()) {
                Text("Quiz on The Gurmukhi Alphabet ->")
                    .padding()//Spacing Inside the Button
                    .frame(maxWidth: 390)//Sets Max Button Width
                    .background(Color.orange)//Button Background Color
                    .foregroundColor(.white)//Button Text Colour
                    .cornerRadius(10)//Rounds Button Corners
            }
            //Navigation Button to Alphabet Puzzle Screen
            NavigationLink(destination: Words()) {
                Text("Let's Learn Some Gurmukhi Words")
                    .padding()//Spacing Inside the Button
                    .frame(maxWidth: 390)//Sets Max Button Width
                    .background(Color.orange)//Button Background Color
                    .foregroundColor(.white)//Button Text Colour
                    .cornerRadius(10)//Rounds Button Corners
            }
            
        }
        
    }
}
    }

