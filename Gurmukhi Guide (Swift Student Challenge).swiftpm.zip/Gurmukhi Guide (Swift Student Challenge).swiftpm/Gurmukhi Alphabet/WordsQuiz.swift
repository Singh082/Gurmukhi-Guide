import SwiftUI

//Main Quiz View
struct WordsQuiz: View {
    //Tracks The Current Question
    @State private var currentQuestion = 0
    //Stores The Selected Anser (a, b, c, d)
    //The term "nil" represents that There is no value here right now
    @State private var selectedAnswer: String? = nil
    //Keeps Track of User Score
    @State private var score = 0
    
    //Array Of Quiz Questions, Options and Correct Answers
    let questions: [(question: String, options: [String], answer: String)] = [
        //Question 1
        ("What Is The Meaning Of: ਕਰ (Kar)", ["a) House", "b) Water", "c) Do", "d) Fear"], "c"),
        
        //Question 2
        ("What Is The Meaning Of: ਘਰ (Ghar)", ["a) Road", "b) Forest", "c) House", "d) Body"], "c"),
        
        //Question 3
        ("What Is The Meaning Of: ਚਲ (Chal)", ["a) Walk/Go", "b) Plow", "c) Enough", "d) Mind"], "a"),
        
        //Question 4
        ("What Is The Meaning Of: ਨਲ (Nal)", ["a) Tap/Pipe", "b) Water", "c) Forest", "d) Wealth"], "a"),
        
        //Question 5
        ("What Is The Meaning Of: ਪਲ (Pal)", ["a) Moment", "b) Fear", "c) Fruit", "d) Road"], "a"),
        
        //Question 6
        ("What Is The Meaning Of: ਜਪ (Jap)", ["a) Walk", "b) Meditate", "c) Read", "d) Tell"], "b")
    ]
    //Start of UI
    var body: some View {
        //Stacks Everything on Top Each Other
            ZStack {
                //Background Image
                Image("Wallpaper")
                    .resizable()//Makes It Resizable
                    .scaledToFill()//Scaled to Fill The Screen
                    .ignoresSafeArea()//Ignores The Safe Area
        
        //Verticallly Stacks Everything Below
        VStack(spacing: 20) {
            //Check IF Quiz is Done
            if currentQuestion < questions.count {
                //Shows the Question
                Text(questions[currentQuestion].question)
                    .font(.title)//Title Size
                    .multilineTextAlignment(.center)//Center Text
                    .foregroundColor(.white)// White Text
                
                //Loop Options
                ForEach(questions[currentQuestion].options, id: \.self) { option in
                    //If Button is Tapped
                    Button(action: {
                        //Get First Letter
                        let choice = String(option.prefix(1)) // get "a", "b", "c", "d"
                        //Saves Choices
                        selectedAnswer = choice
                        
                        //Check if Correct
                        if choice == questions[currentQuestion].answer {
                            score += 1 //Increases Score by 1
                        }
                        //Small Delay
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                            currentQuestion += 1 //Moves To Next Question
                        }
                    }) {
                        //Option Text
                        Text(option)
                            .padding()//Inner Spacing
                            .frame(maxWidth: 350)//Sets The Width
                            .background(Color.orange)//Orange Background
                            .cornerRadius(10)//Rounded Corers
                            .foregroundColor(.white)//White Text
                    }
                }
                //If Answer Chosen
                if let selected = selectedAnswer {
                    //Shows The Result
                    Text(selected == questions[currentQuestion].answer ? "✅ Correct!" : "❌ Wrong!")
                        .foregroundColor(selected == questions[currentQuestion].answer ? .green : .red)//Font is Green Or Red Based On Answer Result
                        .bold()
                }
            } else {
                //Message That Display's Quiz Is Finished
                Text("Quiz Finished!")
                    .font(.title)//Title Size
                    .foregroundColor(.white)//White Text
                    .bold()//Bold
                    .padding()//Spacing
                
                //Shows The Score Of The Quiz
                Text("Your score Is: \(score)/\(questions.count)")
                    .font(.title2)//Title Font
                    .padding()//Spacing
                    .foregroundColor(.white)//White Text
            }
        }
        .padding()
    }
    }
}
