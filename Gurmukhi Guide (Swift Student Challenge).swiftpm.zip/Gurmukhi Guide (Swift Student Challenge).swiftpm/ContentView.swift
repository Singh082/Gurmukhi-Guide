// ContentView
import SwiftUI

//Main Content View of The App
struct ContentView: View {
    var body: some View {
        NavigationView {
            //Allows Stacking Views On Top Of Each Other
            ZStack {
                //Wallpaper Image
                Image("Wallpaper")
                    .resizable()//Makes Image Resizable
                    .scaledToFill()//Fills The Entire Screen
                    .ignoresSafeArea()//Extends under the Safe Area (Borders)
                //Verticle Stack with Spacing
                VStack(spacing: 20) {
                    //App Welcome Text
                    Text("Welcome to The Gurmukhi Guide")
                        .foregroundColor(.white)
                        .bold()
                    //Home Screen (HS) Logo For Gurmukhi Guide
                    Image("HSLogo")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 250)
                    
                    //Stack For Navigation Buttons
                    VStack(spacing: 30) {
                        //Directly Links Homescreen To The Gurmukhi Alphabeet Screen
                        NavigationLink(destination: GurmukhiAlphabet()) {
                            Text("Learn The Gurmukhi Alphabet")
                                .padding()//Allows Spacing Inside The Button
                                .frame(maxWidth: 300)//Buttons Width
                                .background(Color.orange)//Gives Button The Orange Background
                                .foregroundColor(.white)//White Text
                                .cornerRadius(10)//Rounded Corners
                        }
                        //Directly Links Homescreen To The Gurmukhi Numbers Screen
                        NavigationLink(destination: GurmukhiNumbers()) {
                            Text("Learn Gurmukhi Numbers")
                                .padding()//Allows Spacing Inside The Button
                                .frame(maxWidth: 300)//Buttons Width
                                .background(Color.orange)//Gives Button The Organge Background
                                .foregroundColor(.white)//White Text
                                .cornerRadius(10)//Rounded Corners
                        }
                        //Directly Links Homescreen To The Biography Screen Of The Sikh Guru's (Teachers)
                        NavigationLink(destination: Biography()) {
                            Text("Learn About the Guru's")
                                .padding()//Allows Spacing Inside The Button
                                .frame(maxWidth: 300)//Buttons Width
                                .background(Color.orange)//Gives Button The Organge Background
                                .foregroundColor(.white)//White Text
                                .cornerRadius(10)//Rounded Corners
                        }
                        //Directly Links Homescreen To The Screen Of The Sikh Warriors
                        NavigationLink(destination: Warriors()) {
                            Text("Learn About the Sikh Warriors")
                                .padding()//Allows Spacing Inside The Button
                                .frame(maxWidth: 300)//Buttons Width
                                .background(Color.orange)//Gives Button The Organge Background
                                .foregroundColor(.white)//White Text
                                .cornerRadius(10)//Rounded Corners
                        }
                    }
                    
                }
                .padding(.horizontal, 40) //Doesn't Touch The Edges
                
            }
        }
    }
}
