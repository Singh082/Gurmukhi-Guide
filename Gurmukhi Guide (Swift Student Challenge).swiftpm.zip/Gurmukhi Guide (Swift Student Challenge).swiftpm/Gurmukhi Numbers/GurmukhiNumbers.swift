// Gurmukhi Numbers screen
import SwiftUI
// Main view
struct GurmukhiNumbers: View {
    var body: some View { // View body
        // Layered layout
        ZStack {
            // Background image
            Image("Wallpaper")
                .resizable() // Resize image
                .scaledToFill() // Fill screen
                .ignoresSafeArea() // Ignore safe area
            //Vertical layout
            VStack {
                // Page title
                Text("WELCOME TO THE GURMUKHI NUMBERS PAGE") // Text size
                    .bold() // Bold text
                    .padding() // Add spacing
                    .foregroundColor(.white) // White color
                // Numbers image
                Image("Numbers2")
                    .resizable() // Resize image
                    .scaledToFit() // Keep aspect ratio
                    .frame(width: 1000, height: 550) // Image size
                // Question text
                Text("Are You Ready to Take The Quiz?")
                    .foregroundColor(.white) // White color
                    .bold() // Bold text
                
                //Button To Go To Quiz
                NavigationLink(destination: NumbersQuiz()) {
                    // Button text
                    Text("If Yes, Click Here")
                        .padding() // Inner spacing
                        .background(Color.orange) // Button color
                        .foregroundColor(.white) // Text color
                        .cornerRadius(10) // Rounded corners
                }
            }
        }
    }
}
