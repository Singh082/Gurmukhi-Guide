// Numbers Quiz Screen
import SwiftUI

struct NumbersQuiz: View { // Main view
    
    @State private var currentQuestion = 0 // Current question index
    @State private var selectedAnswer: String? = nil // Selected option
    @State private var score = 0 // User score
    
    // Quiz questions, options, and answers
    let questions: [(question: String, options: [String], answer: String)] = [
        ("What Number Is This: ੨", ["a) Sifar - 0", "b) Ek - 1", "c) Dho - 2", "d) Naun - 9"], "c"),
        ("What Number Is This: ੬", ["a) V - 20", "b) Panj - 5", "c) Chhe - 6", "d) Das - 10"], "c"),
        ("What Number Is This: ੧੩", ["a) Teran - 13", "b) Ataran - 18", "c) Satt - 7", "d) Chaar - 4"], "a"),
        ("What Number Is This: ੦", ["a) Sifar - 0", "b) Panj - 5", "c) Ek - 1", "d) V - 20"], "a"),
        ("What Number Is This: ੭", ["a) Satt - 7", "b) Dho - 2", "c) Panj - 5", "d) Chhe - 6"], "a"),
        ("What Number Is This: ੧੧", ["a) Tinn - 3", "b) Giaran - 11", "c) Ataran - 18", "d) Baran - 12"], "b")
    ]
    
    var body: some View { // View body
        ZStack { // Layered layout
            
            Image("Wallpaper") // Background image
                .resizable() // Resize image
                .scaledToFill() // Fill screen
                .ignoresSafeArea() // Ignore safe area
            
            VStack(spacing: 20) { // Vertical layout
                
                if currentQuestion < questions.count { // Check quiz progress
                    
                    Text(questions[currentQuestion].question) // Show question
                        .font(.title) // Title size
                        .multilineTextAlignment(.center) // Center text
                        .foregroundColor(.white) // White text
                        .bold() // Bold text
                    
                    ForEach(questions[currentQuestion].options, id: \.self) { option in // Show options
                        Button(action: {
                            let choice = String(option.prefix(1)) // Get answer letter
                            selectedAnswer = choice // Store selection
                            
                            if choice == questions[currentQuestion].answer { // Check answer
                                score += 1 // Increase score
                            }
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                currentQuestion += 1 // Move to next question
                            }
                        }) {
                            Text(option) // Option text
                                .padding() // Add padding
                                .frame(maxWidth: 350) // Button width
                                .background(Color.orange) // Button color
                                .cornerRadius(10) // Rounded corners
                                .foregroundColor(.white) // White text
                        }
                    }
                    
                    if let selected = selectedAnswer { // Show feedback
                        Text(selected == questions[currentQuestion].answer ? "✅ Correct!" : "❌ Wrong!")
                            .foregroundColor(selected == questions[currentQuestion].answer ? .green : .red)
                            .bold()
                    }
                    
                } else { // Quiz finished
                    
                    Text("Quiz Finished!") // End message
                        .foregroundColor(.white)
                        .font(.title)
                    
                    Text("Your score Is: \(score)/\(questions.count)") // Final score
                        .font(.title2)
                        .padding()
                        .foregroundColor(.white)
                }
            }
            .padding() // Outer padding
        }
    }
}
