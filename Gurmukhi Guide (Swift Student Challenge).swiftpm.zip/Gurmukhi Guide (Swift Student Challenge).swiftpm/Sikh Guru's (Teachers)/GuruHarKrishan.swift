// Guru Har Krishan Sahib Ji screen
import SwiftUI // Imports SwiftUI framework

// Main view for Guru Har Krishan Sahib Ji page
struct GuruHarKrishan: View {
    var body: some View {
        // ZStack layers background and content
        ZStack {
            // Background wallpaper image
            Image("Wallpaper")
                .resizable() // Allows image resizing
                .scaledToFill() // Fills entire screen
                .ignoresSafeArea() // Ignores safe area
            
            // VStack arranges content vertically
            VStack {
                // ScrollView allows scrolling for long content
                ScrollView {
                    
                    // Image of Guru Har Krishan Sahib Ji
                    Image("Guru Har Krishan Sahib Ji")
                        .resizable() // Makes image resizable
                        .scaledToFit() // Keeps image proportions
                        .frame(width: 300, height: 300) // Sets image size
                        .offset(y: 100) // Moves image downward
                    Text("Image By: Dhakkisahib.TV")
                        .foregroundColor(Color.white)
                        .offset(y: 100)
                    
                    // Guru name title
                    Text("Guru Har Krishan Sahib Ji")
                        .font(.headline) // Sets font style
                        .bold() // Makes text bold
                        .offset(y: 100) // Moves text downward
                        .foregroundColor(.white) // Sets text color
                    Text("Gurmukhi: ਗੁਰੂ ਹਰਿਕ੍ਰਿਸ਼ਨ ਸਾਹਿਬ ਜੀ") // Display Guru's name
                        .font(.headline) // Set font style
                        .bold() // Make text bold
                        .offset(y: 100) // Offset text downward
                        .foregroundColor(.white) // Set text color to white
                    
                    // Guru period text
                    Text("Was Guru For: 1661 - 1664")
                        .offset(y: 100) // Moves text downward
                        .foregroundColor(.white) // Sets text color
                    
                    // Divider for visual separation
                    Divider()
                        .offset(y: 100) // Moves divider downward
                    
                    // Detailed biography text
                    Text("Guru Har Krishan (1656-1664) was the eighth of the ten human Sikh Gurus and the younger brother of Guru Har Rai. He was only five years old when he became the Guru in 1661, displaying remarkable spiritual insight and maturity even at such a tender age. However, he interpreted verses from the Guru Granth Sahib and advised people to live their lives with love, tolerance, humility, and devotion to one God. In 1663, when a dreadful outbreak of smallpox and cholera swept through Delhi, the young Guru unhesitatingly devoted himself to the suffering masses. Thousands of people were comforted and cured through his selfless service, especially around what is now known as Gurdwara Bangla Sahib. Unfortunately, while attending to the needs of others, he contracted smallpox and died in 1664 at the tender age of eight. Before his death, he gave the following advice to the Sikhs: “Baba Bakala,” pointing them towards the next Guru, Guru Tegh Bahadur. Guru Har Krishan is remembered as “Bala Pir,” and his life has been a shining example of compassion, humility, and spiritual excellence that knows no bounds of age.")
                        .padding(.bottom, 120) // Adds bottom spacing
                        .frame(maxWidth: .infinity, alignment: .leading) // Aligns text left
                        .multilineTextAlignment(.leading) // Keeps text left-aligned
                        .frame(width: 400, height: .infinity) // Sets text width
                        .offset(y: 100) // Moves text downward
                        .foregroundColor(.white) // Sets text color
                }
            }
        }
    }
}
