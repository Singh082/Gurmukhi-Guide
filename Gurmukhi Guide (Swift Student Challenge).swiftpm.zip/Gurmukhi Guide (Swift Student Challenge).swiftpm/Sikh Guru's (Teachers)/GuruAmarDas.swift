// Guru Amar Das Sahib Ji screen
import SwiftUI

// Main view
struct GuruAmarDas: View {
    // View body
    var body: some View {
        // Layered layout
        ZStack {
            // Background image
            Image("Wallpaper")
                .resizable() // Resize image
                .scaledToFill() // Fill screen
                .ignoresSafeArea() // Ignore safe area
            
            VStack { // Vertical layout
                ScrollView { // Enable scrolling
                    
                    Image("Guru Amar Das Ji") // Guru image
                        .resizable() // Resize image
                        .scaledToFit() // Keep aspect ratio
                        .frame(width: 300, height: 300) // Image size
                        .offset(y: 100) // Move down
                    Text("Image By: SikhWiki")
                        .foregroundColor(Color.white)
                        .offset(y: 100)
                    
                    Text("Guru Amar Das Sahib Ji") // Title text
                        .font(.headline) // Headline size
                        .bold() // Bold text
                        .offset(y: 100) // Move down
                        .foregroundColor(.white) // White color
                    Text("Gurmukhi: ਗੁਰੂ ਅਮਰ ਦਾਸ") // Display Guru's name
                        .font(.headline) // Set font style
                        .bold() // Make text bold
                        .offset(y: 100) // Offset text downward
                        .foregroundColor(.white) // Set text color to white
                    
                    Text("Was Guru For: 1552-1574") // Years as Guru
                        .offset(y: 100) // Move down
                        .foregroundColor(.white) // White color
                    
                    Divider() // Divider line
                        .offset(y: 100) // Move down
                    
                    Text("On Sunday, May 23, 1479, Guru Amar Das Ji (the third Sikh Guru) was born. He died on Thursday, September 16, 1574. Guru Amar Das Ji became a Sikh Guru on April 16, 1552 at the age of 73 after the death of Guru Angad Dev Ji on March 29, 1552, at the age of 48. Guru Nanak Dev Ji, the first of the ten Sikh Gurus, was born ten years before Guru Amar Das Ji. Guru Amar Das Ji  was raised as a shopkeeper in a village called Basarke, where he lived near Amritsar (one of the most famous towns in India). His parents were a farmer and business owner Sri Tej Bhan Ji and devoted Mata Lachmi Ji. He was married to Mata Mansa Devi and had 4 children; two were daughters (Bimbi Dani Ji and Bimbi Bhani Ji) and two were sons (Bhai Mohan and Bhai Mohri) who went on to be successful. His daughter Bibi Bhani married Bhai Jetha, who later became Guru Ram Das Ji, the fourth Guru of the Sikh religion. Guru Amar Das Ji made countless contributions not only to Sikhism but to society as a whole. He wrote 907 hymns that were included in the Sri Guru Granth Sahib Ji; he also wrote the text to Anand Sahib, one of the five Baniis recited daily by committed Sikhs. Guru Amar Das Ji introduced the practice of Langar - the free communal meal to be taken by all people prior to visiting the Guru, as part of his efforts to promote equality between castes and social classes. The breakdown of the caste system was demonstrated by Emperor Akbar, a ruler who participated in Langar and thus made himself equal to all others. Guru Amar Das Ji was likewise directly opposed to veil (parda) and widow (sati) burning customs to provide support for the dignity of and remarriage of women. To efficiently manage his congregants, he shaped the Sikh community using a technique called Manji. In 1552, he founded the town of Goindwal, located along the banks of the Beas River. He appointed Guru Ram Das Ji as his successor prior to passing away in 1574, at the age of 95. Bhai Amar Das Ji was previously a strong follower of the Vaishnava Hindu faith, and followed the tradition of pilgrimage and fasting, until the day he heard Bibi Amro Ji, the daughter of Guru Angad Ji, chant the hymns of Guru Nanak Dev Ji at her house, which ultimately changed his spiritual path. At 61 years old, Bhai Amardas was so moved by becoming a Sikh that he traveled to Khadur Sahib to meet Guru Angad Dev. His dedication to serving both the Guru and the general public earned him the name 'Amru', which means 'Avi', because of his humble and devoted nature. He then settled in Goindwal Sahib, which was being built at that time, and became the third Guru on account of his devotion and commitment to the Sikh faith.") // Biography text
                        .padding(.bottom, 100) // Bottom spacing
                        .frame(maxWidth: .infinity, alignment: .leading) // Align left
                        .multilineTextAlignment(.leading) // Left text
                        .frame(width: 400, height: .infinity) // Text width
                        .offset(y: 100) // Move down
                        .foregroundColor(.white) // White color
                }
            }
        }
    }
}
