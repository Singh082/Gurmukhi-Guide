// Guru Nanak Dev Ji
import SwiftUI // Import SwiftUI framework

struct GuruNanak: View { // Define the GuruNanak view
    var body: some View { // Define the body of the view
        ZStack { // Use ZStack to layer background and content
            Image("Wallpaper") // Background wallpaper image
                .resizable() // Make image resizable
                .scaledToFill() // Scale image to fill the view
                .ignoresSafeArea() // Extend image to ignore safe area
            
            VStack { // Vertical stack for content
                ScrollView { // Scrollable content
                    
                    Image("Guru Nanak Dev Ji") // Display Guru Nanak Dev Ji's image
                        .resizable() // Make image resizable
                        .scaledToFit() // Scale image to fit frame
                        .frame(width: 500, height: 450) // Set fixed frame size
                        .offset(y: 100) // Offset image downward
                    Text("Image By: The KBS Chronicle")
                        .foregroundColor(Color.white)
                        .offset(y: 100)

                    
                    Text("Guru Nanak Dev Ji") // Display Guru's name
                        .font(.headline) // Set font style
                        .bold() // Make text bold
                        .offset(y: 100) // Offset text downward
                        .foregroundColor(.white) // Set text color to white
                    Text("Gurmukhi: ਗੁਰੂ ਨਾਨਕ ਸਾਹਿਬ ਜੀ") // Display Guru's name
                        .font(.headline) // Set font style
                        .bold() // Make text bold
                        .offset(y: 100) // Offset text downward
                        .foregroundColor(.white) // Set text color to white
                    
                    Text("Was Guru For: 1469 - 1539") // Display guruship years
                        .offset(y: 100) // Offset text downward
                        .foregroundColor(.white) // Set text color to white
                    
                    Divider() // Horizontal line divider
                        .offset(y: 100) // Offset divider downward
                    
                    Text("Guru Nanak (1469-1539) was the founder and first Guru of Sikhism. Guru Nanak was born in Talwandi, now known as Nankana Sahib in Pakistan. Guru Nanak was imbued with divine wisdom from childhood and spoke about spirituality from an early age. Guru Nanak believed that rituals, idol worship, and caste were wrong. Guru Nanak’s parents were Mehta Kalu Ji and Mata Tripta Ji. Guru Nanak’s sister, Bebe Nanki Ji, also believed that Guru Nanak was divine. Guru Nanak worked in Sultanpur Lodhi as a young man. Guru Nanak meditated and sang God’s praise along with his companion Bhai Mardana. Guru Nanak traveled thousands of kilometers on four journeys. Guru Nanak spread the message of one God who was formless, fearless, and immortal. Guru Nanak believed in equality, truth, sewa or selfless service, and Naam or remembrance of God’s name. Guru Nanak also established Kartarpur and chose Guru Angad as his successor and successor of divine light.") // Biography text
                        .padding(.bottom, 120) // Bottom padding
                        .frame(maxWidth: .infinity, alignment: .leading) // Expand width and align leading
                        .multilineTextAlignment(.leading) // Align multiline text to leading
                        .frame(width: 400, height: .infinity) // Set explicit frame width
                        .offset(y: 100) // Offset text downward
                        .foregroundColor(.white) // Set text color to white
                }
            }
        }
    }
}

#Preview {
    GuruNanak()
}
