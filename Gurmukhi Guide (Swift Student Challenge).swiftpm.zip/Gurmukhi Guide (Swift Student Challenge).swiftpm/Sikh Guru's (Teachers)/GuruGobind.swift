// Guru Gobind Singh Ji screen
import SwiftUI

// Main view for Guru Gobind Singh Ji
struct GuruGobind: View {
    // View body
    var body: some View {
        ZStack { // Background + content layering
            
            Image("Wallpaper") // Background image
                .resizable() // Make image resizable
                .scaledToFill() // Fill the screen
                .ignoresSafeArea() // Ignore safe areas
            
            VStack { // Vertical layout
                ScrollView { // Enable scrolling
                    
                    Image("Guru Gobind Singh Ji") // Guru image
                        .resizable() // Make image resizable
                        .scaledToFit() // Keep aspect ratio
                        .frame(width: 300, height: 300) // Image size
                        .offset(y: 100) // Move image down
                    Text("Image By: SikhWiki")
                        .foregroundColor(Color.white)
                        .offset(y: 100)
                    
                    Text("Guru Gobind Singh Ji") // Title text
                        .font(.headline) // Headline font
                        .bold() // Bold text
                        .offset(y: 100) // Move text down
                        .foregroundColor(.white) // White text
                    Text("Gurmukhi: ਗੁਰੂ ਗੋਬਿੰਦ ਸਿੰਘ ਜੀ") // Display Guru's name
                        .font(.headline) // Set font style
                        .bold() // Make text bold
                        .offset(y: 100) // Offset text downward
                        .foregroundColor(.white) // Set text color to white
                    
                    Text("Was Guru For: 1675-1708") // Guru years
                        .offset(y: 100) // Move down
                        .foregroundColor(.white) // White text
                    
                    Divider() // Divider line
                        .offset(y: -2) // Slight upward offset
                    
                    Text("Guru Gobind Singh Ji was the tenth and last human guru in the lineage of the Sikhs. He was born as Gobind Das on January 5, 1671, in Patna Sahib, Bihar, and succeeded as guru at the age of nine after the martyrdom of his father, Guru Tegh Bahadur Ji. From a young age, Guru Gobind Singh Ji had shown remarkable bravery, leadership skills, and commitment to truth and justice. In 1699, Guru Gobind Singh founded the Khalsa in Anandpur Sahib, a new community of initiated Sikhs with a common goal of equality, religion, and bravery. Guru Gobind Singh Ji also introduced the 'Panj Pyare' or 'Five Beloved Ones' through the rite of Amrit in the Khalsa, emphasizing the spirit of the Saint-Soldier, firm in their religion and brave in their defense of truth and righteousness. Guru Gobind Singh Ji  also declared the Guru Granth Sahib as the eternal guru before his death in 1708. Guru Gobind Singh Ji was a brave warrior, a talented poet, and a profound philosopher, and during his reign, he wrote many inspiring compositions like 'Jaap Sahib' and 'Akal Ustad.' Guru Gobind Singh Ji was a firm opponent of oppression and tyranny, and under his leadership, the Sikhs developed a new identity.") // Biography text
                        .padding(.bottom, 120) // Bottom spacing
                        .frame(maxWidth: .infinity, alignment: .leading) // Left align text
                        .multilineTextAlignment(.leading) // Multiline alignment
                        .frame(width: 400, height: .infinity) // Text width
                        .offset(y: 100) // Move text down
                        .foregroundColor(.white) // White text
                }
            }
        }
    }
}
