// Guru Arjan Dev Ji screen
import SwiftUI

// Main view
struct GuruArjanDev: View {
    // View body
    var body: some View {
        // Layered layout
        ZStack {
            // Background image
            Image("Wallpaper")
                .resizable() // Make image resizable
                .scaledToFill() // Fill entire screen
                .ignoresSafeArea() // Ignore safe areas
            
            VStack { // Vertical stack
                ScrollView { // Enable scrolling
                    
                    Image("Guru Arjan Dev Ji") // Guru image
                        .resizable() // Make image resizable
                        .scaledToFit() // Maintain aspect ratio
                        .frame(width: 300, height: 300) // Image size
                        .offset(y: 100) // Move image down
                    Text("Image By: DhakkiSahib.TV")
                        .foregroundColor(Color.white)
                        .offset(y: 100)
                    
                    Text("Guru Arjan Sahib Ji") // Title text
                        .font(.headline) // Headline font
                        .bold() // Bold text
                        .offset(y: 100) // Move down
                        .foregroundColor(.white) // White text
                    Text("Gurmukhi: ਗੁਰੂ ਅਰਜੁਨ ਸਾਹਿਬ ਜੀ") // Display Guru's name
                        .font(.headline) // Set font style
                        .bold() // Make text bold
                        .offset(y: 100) // Offset text downward
                        .foregroundColor(.white) // Set text color to white
                    
                    Text("Was Guru For: 1581 - 1606") // Guru years
                        .offset(y: 100) // Move down
                        .foregroundColor(.white) // White text
                    
                    Divider() // Divider line
                        .offset(y:100) // Move divider down
                    
                    Text("Guru Arjan Dev Ji (born Goindval, Punjab, May 2, 1563) was the youngest son of Guru Ram Das Ji and Bibi Bhani Ji. From early childhood, he exhibited a very high level of spirituality, humility and devotion to selfless service (seva). Although his brother Prithi Chand sought to obtain the Guruship through manipulation, Guru Arjan Dev Ji continued to display patience, compassion, and freedom from hostility. He was officially the fifth Guru of Sikhism in 1581, at 18 years of age. Guru Arjan Dev Ji created an institutional and spiritual foundation for Sikhism. His most significant contribution was to compile and verify the Adi Granth (now referred to as Guru Granth Sahib) which preserved the hymns of previous Gurus, and the hymns of saints from all castes and different religions. He also authored many of the hymns himself, including Sukhmani Sahib. Guru Arjan Dev Ji was instrumental in building the Harmandir Sahib (Golden Temple) which represents equality, and access to God for all people, as well as establishing Amritsar as a center for spirituality, by overseeing its construction. As the first Sikh Guru to become a martyr, Guru Arjan Dev Ji accepted suffering with grace and faith, and therefore received the title of Shaheedan-De-Sartaaj(Crown of Martyrs). Before his passing, he appointed his son, Guru Hargobind Sahib Ji, initiating a new era of resistance to injustice in Sikh history.") // Biography text
                        .padding(.bottom, 120) // Bottom spacing
                        .frame(maxWidth: .infinity, alignment: .leading) // Left alignment
                        .multilineTextAlignment(.leading) // Text alignment
                        .frame(width: 400, height: .infinity) // Text width
                        .offset(y: 100) // Move down
                        .foregroundColor(.white) // White text
                }
            }
        }
    }
}
