// Guru Tegh Bahadur Sahib Ji
import SwiftUI // Import SwiftUI framework

struct GuruTeghBahadur: View { // Define the GuruTeghBahadur view
    var body: some View { // Define the body of the view
        ZStack { // Use ZStack to layer background and content
            Image("Wallpaper") // Background wallpaper image
                .resizable() // Make image resizable
                .scaledToFill() // Scale image to fill the view
                .ignoresSafeArea() // Extend image to ignore safe area
            
            VStack { // Vertical stack for content
                ScrollView { // Scrollable content
                    
                    Image("Guru Tegh Bahadur Sahib Ji") // Display Guru Tegh Bahadur Sahib Ji's image
                        .resizable() // Make image resizable
                        .scaledToFit() // Scale image to fit frame
                        .frame(width: 300, height: 300) // Set fixed frame size
                        .offset(y: 100) // Offset image downward
                    Text("Image By: Dasvandh Network")
                        .foregroundColor(Color.white)
                        .offset(y: 100)

                    
                    Text("Guru Tegh Bahadur Sahib Ji") // Display Guru's name
                        .font(.headline) // Set font style
                        .bold() // Make text bold
                        .offset(y: 100) // Offset text downward
                        .foregroundColor(.white) // Set text color to white
                    Text("Gurmukhi: ਗੁਰੂ ਤੇਗ਼ ਬਹਾਦੁਰ ਸਾਹਿਬ ਜੀ") // Display Guru's name
                        .font(.headline) // Set font style
                        .bold() // Make text bold
                        .offset(y: 100) // Offset text downward
                        .foregroundColor(.white) // Set text color to white
                    
                    Text("Was Guru For: 1665 - 1675") // Display guruship years
                        .offset(y: 100) // Offset text downward
                        .foregroundColor(.white) // Set text color to white
                    
                    Divider() // Horizontal line divider
                        .offset(y: 100) // Offset divider downward
                    
                    Text("Guru Tegh Bahadur (1621–1675) was the ninth Sikh Guru and is revered as Hind-di-Chadar, the Protector of Humanity. Born Tyag Mal in Amritsar to Guru Hargobind, he was trained in martial arts, scriptures, and philosophy. After showing courage in battle at a young age, he was named “Tegh Bahadur,” meaning Brave Sword. Though he was a warrior by skill, he led a very spiritual and meditative life. He became the Guru in 1664 after Guru Har Krishan. His 116 hymns have been included in the Guru Granth Sahib. His teachings emphasize detachment, courage, devotion, and acceptance of God’s will. He also founded Chak-Nanki, now known as Anandpur Sahib. When Kashmiri Pandits approached Guru Tegh Bahadur in 1675 for help against the forced conversion of Kashmiris by Emperor Aurangzeb, Guru Tegh Bahadur stood up for religious freedom. He refused to convert and was beheaded in public in Delhi. Gurdwara Sis Ganj Sahib and Rakab Ganj Sahib mark the spot where he was martyred and cremated. They symbolize his supreme sacrifice for human rights and freedom of belief.") // Detailed biography text
                        .padding(.bottom, 130) // Bottom padding
                        .frame(maxWidth: .infinity, alignment: .leading) // Expand width and align leading
                        .multilineTextAlignment(.leading) // Align multiline text to leading
                        .frame(width: 400, height: .infinity) // Set explicit frame width
                        .offset(y: 100) // Offset text downward
                        .foregroundColor(.white) // Set text color to white
                }
            }
        }
    }
}
