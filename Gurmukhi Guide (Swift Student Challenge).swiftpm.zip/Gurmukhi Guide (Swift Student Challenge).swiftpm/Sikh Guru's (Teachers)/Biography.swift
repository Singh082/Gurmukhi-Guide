// Biography screen
import SwiftUI

struct Biography: View { // Main view
    var body: some View { // View body
        ZStack { // Layered layout
            
            Image("Wallpaper") // Background image
                .resizable() // Resize image
                .scaledToFill() // Fill screen
                .ignoresSafeArea() // Ignore safe area
            
            ScrollView { // Enable scrolling
                HStack { // Horizontal layout
                    VStack { // Vertical layout
                        
                        Text("Learn About the Sikh Guru's (Teachers)") // Title text
                            .font(.title2) // Text size
                            .padding() // Add padding
                            .bold() // Bold text
                            .offset(x: 5, y: 50) // Position text
                            .foregroundColor(.white) // White color
                        
                        Text("Please Press The Picture To Learn Their Name") // Instruction text
                            .padding() // Add padding
                            .bold() // Bold text
                            .offset(x: 5, y: 20) // Position text
                            .foregroundColor(.white) // White color
                        
                        NavigationLink(destination: GuruNanak()) { // Go to Guru Nanak
                            Image("Guru Nanak Dev Ji") // Guru image
                                .resizable() // Resize image
                                .scaledToFit() // Keep ratio
                                .frame(width: 250, height: 250) // Image size
                                .padding() // Add padding
                        }
                        
                        Divider() // Divider line
                            .offset(x: 25, y: 90) // Position divider
                        
                        NavigationLink(destination: GuruAngad()) { // Go to Guru Angad
                            Image("Guru Angad Dev Ji") // Guru image
                                .resizable()
                                .scaledToFit()
                                .frame(width: 250, height: 250)
                                .padding()
                        }
                        
                        Divider() // Divider line
                            .offset(x: 25, y: 130)
                        
                        NavigationLink(destination: GuruAmarDas()) { // Go to Guru Amar Das
                            Image("Guru Amar Das Ji")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 250, height: 250)
                                .padding()
                        }
                        
                        Divider() // Divider line
                            .offset(x: 25, y: 150)
                        
                        NavigationLink(destination: GuruRamDas()) { // Go to Guru Ram Das
                            Image("Guru Ram Das Ji")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 250, height: 250)
                                .padding()
                        }
                        
                        Divider() // Divider line
                            .offset(x: 25, y: 170)
                        
                        NavigationLink(destination: GuruArjanDev()) { // Go to Guru Arjan Dev
                            Image("Guru Arjan Dev Ji")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 250, height: 250)
                                .padding()
                        }
                        
                        Divider() // Divider line
                            .offset(x: 25, y: 190)
                        
                        NavigationLink(destination: GuruHarGobind()) { // Go to Guru Har Gobind
                            Image("Guru Har Gobind Sahib Ji")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 250, height: 250)
                                .padding()
                        }
                        
                        Divider() // Divider line
                            .offset(x: 25, y: 210)
                        
                        NavigationLink(destination: GuruHarRai()) { // Go to Guru Har Rai
                            Image("Guru Har Rai Sahib Ji")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 250, height: 250)
                                .padding()
                        }
                        
                        Divider() // Divider line
                            .offset(x: 25, y: 230)
                        
                        NavigationLink(destination: GuruHarKrishan()) { // Go to Guru Har Krishan
                            Image("Guru Har Krishan Sahib Ji")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 250, height: 250)
                                .padding()
                        }
                        
                        Divider() // Divider line
                            .offset(x: 25, y: 250)
                        
                        NavigationLink(destination: GuruTeghBahadur()) { // Go to Guru Tegh Bahadur
                            Image("Guru Tegh Bahadur Sahib Ji")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 250, height: 250)
                                .padding()
                        }
                        
                        Divider() // Divider line
                            .offset(x: 25, y: 270)
                        
                        NavigationLink(destination: GuruGobind()) { // Go to Guru Gobind Singh
                            Image("Guru Gobind Singh Ji")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 250, height: 250)
                                .padding()
                        }
                        
                        Divider() // Divider line
                            .offset(x: 25, y: 290)
                        
                        NavigationLink(destination: GuruGranth()) { // Go to Guru Granth Sahib
                            Image("Guru Granth Sahib Ji")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 250, height: 250)
                                .padding()
                                .padding(.bottom) // Bottom padding
                        }
                    }
                    .padding(.bottom, 500) // Extra scroll space
                }
            }
        }
    }
}
