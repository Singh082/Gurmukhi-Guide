// Guru Granth Sahib Ji screen
import SwiftUI // Imports SwiftUI framework for building UI

// Main view for Guru Granth Sahib Ji page
struct GuruGranth: View {
    var body: some View {
        // ZStack to layer background and content
        ZStack {
            // Background wallpaper image
            Image("Wallpaper")
                .resizable() // Allows image to resize
                .scaledToFill() // Fills the entire screen
                .ignoresSafeArea() // Extends image beyond safe areas
            
            // Vertical stack to organize content
            VStack {
                // ScrollView allows scrolling for long content
                ScrollView {
                    
                    // Image of Guru Granth Sahib Ji
                    Image("Guru Granth Sahib Ji")
                        .resizable() // Makes image resizable
                        .scaledToFit() // Maintains aspect ratio
                        .frame(width: 300, height: 300) // Sets image size
                        .offset(y: 100) // Moves image downward
                    Text("Image By: Basics Of Sikhi")
                        .foregroundColor(Color.white)
                        .offset(y: 100)
                    
                    // Title text
                    Text("Guru Granth Sahib Ji")
                        .font(.headline) // Sets font style
                        .bold() // Makes text bold
                        .offset(y: 100) // Moves text downward
                        .foregroundColor(.white) // Sets text color
                    Text("Gurmukhi: ਸ੍ਰੀਗੁਰੂਗ੍ਰੰਥਸਾਹਿਬਜੀ") // Display Guru's name
                        .font(.headline) // Set font style
                        .bold() // Make text bold
                        .offset(y: 100) // Offset text downward
                        .foregroundColor(.white) // Set text color to white
                    
                    // Time period text
                    Text("Is Guru For: 1708 - Eternity")
                        .offset(y: 100) // Moves text downward
                        .foregroundColor(.white) // Sets text color
                    
                    // Divider line for visual separation
                    Divider()
                        .offset(y: 100) // Moves divider downward
                    
                    // Detailed description text
                    Text("The Guru Granth Sahib, also referred to as the Adi Granth, is regarded not merely as a holy text but as the eternal living Guru of the Sikh people. Guru Gobind Singh declared in 1708 that he would be succeeded by no other than the Guru Granth Sahib. Instead he said, “Sab Sikhan ko hukam hai Guru Manyo Granth.” Therefore, the Sikhs recognize the Ten Human Gurus and the Guru Granth Sahib as the Eleventh and Eternal Guru for the answers to everything. The Guru Granth Sahib has 1430 Pages of Hymns composed by the Sikhs Gurus, starting with Guru Nanak, as well as numerous other Hindus, Buddhists and Sufi Saints such as Kabir and Sheikh Farid; reflecting the Sikh belief in One God and the Unity of Humanity without regard to the caste or religious distinctions that separate us all. The Guru Granth Sahib was compiled by Guru Arjan Dev Ji, and completed by Guru Gobind Singh with the addition of newly composed hymns to include those of Guru Tegh Bahadur Ji. All Scriptures within the Guru Granth Sahib are written in Gurmukhi and arranged according to Musical Measures for singing. Therefore, within every Sikh Gurdwara, the Guru Granth Sahib is given the highest place of respect and is the centrepiece of the Gurdwara to provide all Sikhs with unhindered access to Divine Guidance and Spiritual Authority.")
                        .padding(.bottom, 120) // Adds space at bottom
                        .frame(maxWidth: .infinity, alignment: .leading) // Aligns text to left
                        .multilineTextAlignment(.leading) // Ensures left text alignment
                        .frame(width: 400, height: .infinity) // Sets text width
                        .offset(y: 100) // Moves text downward
                        .foregroundColor(.white) // Sets text color
                }
            }
        }
    }
}
