// Guru Har Gobind Sahib Ji screen
import SwiftUI

// Main view for Guru Har Gobind Sahib Ji page
struct GuruHarGobind: View {
    var body: some View {
        // ZStack layers background and content
        ZStack {
            // Background wallpaper image
            Image("Wallpaper")
                .resizable() // Allows image resizing
                .scaledToFill() // Fills entire screen
                .ignoresSafeArea() // Ignores safe area edges
            
            // VStack arranges content vertically
            VStack {
                // ScrollView allows scrolling for long content
                ScrollView {
                    
                    // Image of Guru Har Gobind Sahib Ji
                    Image("Guru Har Gobind Sahib Ji")
                        .resizable() // Makes image resizable
                        .scaledToFit() // Maintains aspect ratio
                        .frame(width: 300, height: 300) // Sets image size
                        .offset(y: 100) // Moves image downward
                    Text("Image By: SikhiWiki")
                        .foregroundColor(Color.white)
                        .offset(y: 100)
                    
                    // Guru name title
                    Text("Guru Har Gobind Sahib Ji")
                        .font(.headline) // Sets font style
                        .bold() // Makes text bold
                        .offset(y: 100) // Moves text downward
                        .foregroundColor(.white) // Sets text color
                    Text("Gurmukhi: ਗੁਰੂ ਹਰਿਗੋਬਿੰਦ ਸਾਹਿਬ ਜੀ") // Display Guru's name
                        .font(.headline) // Set font style
                        .bold() // Make text bold
                        .offset(y: 100) // Offset text downward
                        .foregroundColor(.white) // Set text color to white
                    
                    // Guru period text
                    Text("Was Guru For: 1606 - 1644")
                        .offset(y: 100) // Moves text downward
                        .foregroundColor(.white) // Sets text color
                    
                    // Divider for visual separation
                    Divider()
                        .offset(y: 100) // Moves divider downward
                    
                    // Detailed biography text (unchanged)
                    Text("Guru Hargobind (1595–1644) was the sixth of the ten Sikh Gurus, Guru Arjan's son, and became Guru at 11 years old in the year 1606. Following his father's martyrdom, Guru Hargobind made a significant change in the leadership of the Sikh faith by joining militaristic military might with the spiritual. During his appointment as Guru, He wore two swords, Miri and Piri, signifying the dual authority of worldly power and spiritual authority, meaning that a Sikh must now have both the characteristics of saint and soldier. Rather than wear the traditional wool band as a thread - as did his predecessors, Guru Hargobind chose instead to wear his military garb. By doing so, he was conveying the message that it was imperative for Sikhs to protect the innocent and stand against oppression. In the year 1606, Guru Hargobind constructed the Akal Takht (the throne of the Timeless One) opposite the Harmandar Sahib as a physical representation of the temporal authority of the Guru and ushered in the building of Lohgarh Fort in Amritsar and impressed upon Sikhs the need to have a disciplined military. Guru Hargobind built the foundation for the militarization of the Sikh faith, while maintaining spiritual guidance and directing the Sikhs to become a disciplined and sovereign entity.")
                        .padding(.bottom, 120) // Adds space at bottom
                        .frame(maxWidth: .infinity, alignment: .leading) // Aligns text to left
                        .multilineTextAlignment(.leading) // Keeps text left-aligned
                        .frame(width: 400, height: .infinity) // Sets text width
                        .offset(y: 100) // Moves text downward
                        .foregroundColor(.white) // Sets text color
                }
            }
        }
    }
}
