// Guru Angad Dev Ji screen
import SwiftUI

// Main view
struct GuruAngad: View {
    // View body
    var body: some View {
        // Layered layout
        ZStack {
            // Background image
            Image("Wallpaper")
                .resizable() // Make resizable
                .scaledToFill() // Fill screen
                .ignoresSafeArea() // Ignore safe area
            
            VStack { // Vertical stack
                ScrollView { // Enable scrolling
                    
                    Image("Guru Angad Dev Ji") // Guru image
                        .resizable() // Make resizable
                        .scaledToFit() // Keep aspect ratio
                        .frame(width: 300, height: 450) // Image size
                        .offset(y: 100) // Move down
                        .foregroundColor(.white) // White tint
                    Text("Image By: SikhWiki")
                        .foregroundColor(Color.white)
                        .offset(y: 100)
                    
                    Text("Guru Angad Sahib Ji") // Title text
                        .font(.headline) // Headline font
                        .bold() // Bold text
                        .offset(y: 100) // Move down
                        .foregroundColor(.white) // White color
                    Text("Gurmukhi: ਗੁਰੂ ਅੰਗਦ ਸਾਹਿਬ ਜੀ") // Display Guru's name
                        .font(.headline) // Set font style
                        .bold() // Make text bold
                        .offset(y: 100) // Offset text downward
                        .foregroundColor(.white) // Set text color to white
                    
                    Text("Was Guru For: 1539 - 1552") // Years as Guru
                        .offset(y: 100) // Move down
                        .foregroundColor(.white) // White color
                    
                    Divider() // Divider line
                        .offset(y: 100) // Move down
                    
                    Text("On March 31st, 1504, Guru Angad Dev Ji, originally named Bhai Lehna Ji, was born to a prosperous trader (Bhai Pheru Mall) and Mata Ramo Ji in the Punjabi village of Matte Di Sarai (Sarainaga), which lies within present day Sri Muktsar Sahib district. At an early age, Bhai Lehna Ji worshipped the Hindu goddess Durga, with the influence of his mother, and made annual pilgrimages to the Jawalamukhi Temple. In 1520 he married Mata Khivi Ji and had four children. However, when Mughal and Baloch forces invaded the region, his family moved to Khadur Sahib. One important day, while listening to the hymns sung by Guru Nanak Sahib Ji, Bhai Lehna Ji was so moved by what he heard that he decided to visit Kartarpur where he met Guru Nanak Dev Ji, and was given the name Angad and became formally a Sikh of the Guru. After this experience he became devoted to Guru Nanak, and was appointed as his successor in 1539. As the new Guru, Guru Angad Dev Ji continued to develop the teachings of Guru Nanak Dev Ji and introduced the Gurmukhi script; while also expanding the practice of education for all through the growth of langar, the establishment of schools and dharamsalas and composing numerous saloks that he later had included in the Guru Granth Sahib Ji. Before he died in 1552, Guru Angad Dev Ji also appointed Guru Amar Das as the next Guru (the Third Nanak) so that there would continue to be a clearly defined leader and identity for the Sikh people.") // Biography text
                        .padding(.bottom, 150) // Bottom spacing
                        .frame(maxWidth: .infinity, alignment: .leading) // Align left
                        .multilineTextAlignment(.leading) // Left align text
                        .frame(width: 400, height: .infinity) // Text width
                        .offset(y: 100) // Move down
                        .foregroundColor(.white) // White color
                }
            }
        }
    }
}
