// Guru Ram Das Sahib Ji
import SwiftUI // Import SwiftUI framework

struct GuruRamDas: View { // Define the GuruRamDas view
    var body: some View { // Define the body of the view
        ZStack { // Use ZStack to layer background and content
            Image("Wallpaper") // Background wallpaper image
                .resizable() // Make image resizable
                .scaledToFill() // Scale image to fill the view
                .ignoresSafeArea() // Extend image to ignore safe area
            
            VStack { // Vertical stack for content
                ScrollView { // Scrollable content
                    
                    Image("Guru Ram Das Ji") // Display Guru Ram Das Ji's image
                        .resizable() // Make image resizable
                        .scaledToFit() // Scale image to fit frame
                        .frame(width: 300, height: 300) // Set fixed frame size
                        .offset(y: 100) // Offset image downward
                    Text("Image By: Dasvandh Network")
                        .foregroundColor(Color.white)
                        .offset(y: 100)

                    
                    Text("Guru Ram Das Sahib Ji") // Display Guru's name
                        .font(.headline) // Set font style
                        .bold() // Make text bold
                        .offset(y: 100) // Offset text downward
                        .foregroundColor(.white) // Set text color to white
                    Text("Gurmukhi: ਗੁਰੂ ਰਾਮ ਦਾਸ ਸਾਹਿਬ ਜੀ") // Display Guru's name
                        .font(.headline) // Set font style
                        .bold() // Make text bold
                        .offset(y: 100) // Offset text downward
                        .foregroundColor(.white) // Set text color to white
                    
                    Text("Was Guru For: 1574 - 1581") // Display guruship years
                        .offset(y: 100) // Offset text downward
                        .foregroundColor(.white) // Set text color to white
                    
                    Divider() // Horizontal line divider
                        .offset(y: 100) // Offset divider downward
                    
                    Text("Guru Ram Das, born Jetha in Lahore, was the fourth Guru in Sikhism. At a young age, Guru Ram Das was orphaned and brought up by his grandmother. Later, Guru Ram Das met Guru Amar Das when he was just twelve years old. Thereafter, Guru Ram Das dedicated himself to service. Guru Amar Das, recognizing Guru Ram Das's commitment to service, gave his daughter, Bibi Bhani Ji, in marriage to Guru Ram Das in 1574 and appointed Guru Ram Das as the fourth Guru in 1574, renaming him Ram Das, meaning 'Servant of God.' Guru Ram Das contributed 638 hymns to the Guru Granth Sahib, which are in various ragas. Guru Ram Das's message focuses on humility, gratitude, living a disciplined life, and remembering God's Name. Guru Ram Das developed the city of Ramdaspur, which came to be known as Amritsar, and served as the spiritual and administrative hub for Sikhism. Guru Ram Das developed the 'four Laavan' hymns, which laid the foundation for the Sikh marriage rite known as 'Anand Karaj.' Before passing away in 1581, Guru Ram Das appointed Guru Arjan, his youngest son, as the Guru.") // Detailed biography text
                        .padding(.bottom, 120) // Bottom padding
                        .frame(maxWidth: .infinity, alignment: .leading) // Expand width and align leading
                        .multilineTextAlignment(.leading) // Align multiline text to leading
                        .frame(width: 400, height: .infinity) // Set explicit frame width
                        .offset(y: 100) // Offset text downward
                        .foregroundColor(.white) // Set text color to white
                }
            }
        }
    }
}
