// Guru Har Rai Sahib Ji
import SwiftUI

struct GuruHarRai: View { // Define the GuruHarRai view
    var body: some View { // Define the body of the view
        ZStack { // Use ZStack to layer background and content
            Image("Wallpaper") // Background wallpaper image
                .resizable() // Make image resizable
                .scaledToFill() // Scale image to fill the view
                .ignoresSafeArea() // Extend image to ignore safe area
            
            VStack { // Vertical stack for content
                ScrollView { // Scrollable content
                    Image("Guru Har Rai Sahib Ji") // Display Guru's image
                        .resizable() // Make image resizable
                        .scaledToFit() // Scale image to fit its frame
                        .frame(width: 300, height: 300) // Set fixed frame size
                        .offset(y: 100) // Offset image downward
                    Text("Image By: Dhakkisahib.TV")
                        .foregroundColor(Color.white)
                        .offset(y: 100)
                    
                    Text("Guru Har Rai Sahib Ji") // Display Guru's name
                        .font(.headline) // Set font style
                        .bold() // Make text bold
                        .offset(y: 100) // Offset text downward
                        .foregroundColor(.white) // Set text color to white
                    Text("Gurmukhi: ਗੁਰੂ ਹਰਿ ਰਾਇ ਸਾਹਿਬ ਜੀ") // Display Guru's name
                        .font(.headline) // Set font style
                        .bold() // Make text bold
                        .offset(y: 100) // Offset text downward
                        .foregroundColor(.white) // Set text color to white
                    
                    Text("Was Guru For: 1644 to 1661") // Display guruship years
                        .offset(y: 100) // Offset text downward
                        .foregroundColor(.white) // Set text color to white
                    
                    Divider() // Horizontal line divider
                        .offset(y: 100) // Offset divider downward
                    
                    Text("Guru Har Rai (1630-1661) was the seventh Sikh Guru and the grandson of Guru Hargobind. Born to Baba Gurdita Ji and Mata Nihal Kaur Ji, Guru Har Rai led a disciplined and spiritual life. Though he was a peaceful man himself, he kept up his grandfather’s Sikh army. Guru Har Rai never engaged in any conflict with the Mughal Empire but also demonstrated bravery and self-defense. The Guru helped Dara Shikoh, the son of Emperor Shah Jahan, by sending him rare kinds of herbal medicine that helped save his life. Though he was offered any reward from the emperor for saving his son’s life, Guru Har Rai refused. At Kiratpur Sahib, Guru Har Rai established an institution of Ayurvedic medicine and advocated compassion for all living beings. The Guru also enhanced missionary activities among the Sikhs through establishing 360 Manjis. By being humble, helpful, and having strong faith in his principles, Guru Har Rai led the Sikh community through difficult times and paved the way for his son Guru Har Krishan.") // Detailed biography text
                        .padding(.bottom, 120) // Padding at the bottom
                        .frame(maxWidth: .infinity, alignment: .leading) // Expand width and align leading
                        .multilineTextAlignment(.leading) // Align text to leading for multiple lines
                        .frame(width: 400, height: .infinity) // Set explicit frame width
                        .offset(y: 100) // Offset text downward
                        .foregroundColor(.white) // Set text color to white
                }
            }
        }
    }
}
